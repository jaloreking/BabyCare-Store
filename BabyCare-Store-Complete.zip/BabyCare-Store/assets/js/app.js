
function renderProducts(){
const container=document.getElementById("product-list");
if(!container) return;
container.innerHTML="";
products.forEach(p=>{
container.innerHTML+=`
<div class="product">
<img src="${p.image}" alt="${p.name}" width="100%">
<h3>${p.name}</h3>
<p>₹ ${p.price}</p>
<button onclick="addToCart(${p.id})">Add to Cart</button>
<button onclick="addToWishlist(${p.id})">Wishlist</button>
</div>`;
});
}

function addToCart(id){
let cart=JSON.parse(localStorage.getItem("cart"))||[];
cart.push(id);
localStorage.setItem("cart",JSON.stringify(cart));
alert("Added to Cart");
}

function addToWishlist(id){
let w=JSON.parse(localStorage.getItem("wishlist"))||[];
w.push(id);
localStorage.setItem("wishlist",JSON.stringify(w));
alert("Added to Wishlist");
}

document.addEventListener("DOMContentLoaded",renderProducts);
